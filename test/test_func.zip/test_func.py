import json

"""   scrape   """
import requests
from bs4 import BeautifulSoup
import urllib

players = {
    "CR7": {"team": "Ubentus", "number": 7, "nation": "Portugees", "position": "FW"},
    "Messi": {"team": "FCBarcelona", "number": 10, "nation": "Argentina", "position": "FW"},
    "Ibra": {"team": "AC Milan", "number": 11, "nation": "Sweden", "position": "FW"}
}

def scrape(url_):
    lst_ = []
    soup = BeautifulSoup(url_, 'html.parser')
    for item in soup.find_all("div", class_="items-box"):
        lst_.append(item)
    return lst_

def player_list():
    items = players
    return items
    
def mercari_list(keyword_):
    origin = "https://www.mercari.com/jp/search/"
    keyword = urllib.parse.quote(keyword_)
    target_url = "".join[origin, '?keyword=', keyword]
    return scrape(target_url)

def lambda_handler(event, context):
    OperationType = event["OperationType"]
    
    try:
        if OperationType == "LIST_PLAYERS":
            return {
                'statusCode': 200,
                'headers': {
                    "Content-Type": 'application/json',
                    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                    "Access-Control-Allow-Methods": "POST, OPTION, GET",
                    "Access-Control-Allow-Origin": "*"
                },
                'body': json.dumps(player_list())
            }
        #elif OperationType == "MER_LIST":
        else:
            keyword_ = event["Keys"]["keyword"]
            return mercari_list(keyword_)
    except Exception as e:
        print("Error: ")
        print(e)